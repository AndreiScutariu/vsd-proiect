namespace Vsd.Slave.Leaf.Slaves.Utils
{
    public class Settings
    {
        public int SlaveKey { get; set; }

        public int DrawType { get; set; }

        public int DrawColor { get; set; }

        public int DrawRotation { get; set; }

        public int InternalId { get; set; }
    }
}